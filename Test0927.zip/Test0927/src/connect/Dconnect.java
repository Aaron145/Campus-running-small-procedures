package connect;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import stu.Order;
import stu.Student;

public class Dconnect {
	
	private String driverClass;
	private String database;
	private String username;
	private String password;
	
	public Dconnect(String driverClass, String database, String username, String password) {
		super();
		this.driverClass = driverClass;
		this.database = database;
		this.username = username;
		this.password = password;
	}
	//��¼	
	public boolean check(String name,String tel) throws ClassNotFoundException, SQLException {
		Connection con=null;
		boolean result=false;
		
		Class.forName(driverClass);
		con = DriverManager.getConnection(database, username, password);
			
		String spl="SELECT * FROM login WHERE username=? AND tel=?";
		PreparedStatement ps=con.prepareStatement(spl);
		ps.setString(1, name);
		ps.setString(2, tel);
		ResultSet rs = ps.executeQuery();
			
		if(rs.next()) {

			    return result = true;

		}
		ps.close();
		con.close();
		
		return result;
			
	}
	//ע��
	public int register(String name,String tel) {
		Connection conn = null;
		int i=0;
		try {
			
			Class.forName(driverClass);
			conn = DriverManager.getConnection(database, username, password);
			
			String sql = "insert into login (username,tel) values(?,?)";
			PreparedStatement pstat = conn.prepareStatement(sql);
			pstat.setString(1, name);
			pstat.setString(2, tel);
			i = pstat.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (conn != null) {
					conn.close();
					conn = null;
				}
			} catch (Exception ex) {
			}
		}
		return i;
	}
	//ע����
	public boolean registercheck(String tel) throws ClassNotFoundException, SQLException {
		Connection con=null;
		boolean result=true;
		
		Class.forName(driverClass);
		con = DriverManager.getConnection(database, username, password);
			
		String spl="select * from login where tel=?";
		PreparedStatement ps=con.prepareStatement(spl);
		ps.setString(1, tel);
		ResultSet rs = ps.executeQuery();
			
		if(rs.next()) {

			    return result = false;

		}
		ps.close();
		con.close();
		
		return result;
			
	}
	//��ѯ���ж���
	public ArrayList query() {
		Connection con = null;
		ArrayList orders = new ArrayList();
		try {
			
			Class.forName(driverClass);
			con = DriverManager.getConnection(database, username, password);
			
			String sql = "SELECT * from wechar.`order`";
			Statement stat = con.createStatement();
			ResultSet rs = stat.executeQuery(sql);
			while (rs.next()) {
				Order order = new Order();
				order.setOrderID(rs.getInt("orderID"));
				order.setReceive(rs.getString("receive"));
				order.setDestination(rs.getString("destination"));
				order.setBrokerage(rs.getString("brokerage"));
				order.setTel(rs.getString("tel"));
				orders.add(order);
			}
			rs.close();
			stat.close();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (con != null) {
					con.close();
					con = null;
				}
			} catch (Exception ex) {
			}
		}
		return orders;
	}
	//�鿴���˶���
	public ArrayList selfquery(String tel) {
		Connection con = null;
		ArrayList orders = new ArrayList();
		try {
			
			Class.forName(driverClass);
			con = DriverManager.getConnection(database, username, password);
			
			String spl="SELECT * from wechar.`order` where tel=?";
			PreparedStatement ps=con.prepareStatement(spl);
			ps.setString(1, tel);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				Order order = new Order();
				order.setOrderID(rs.getInt("orderID"));
				order.setReceive(rs.getString("receive"));
				order.setDestination(rs.getString("destination"));
				order.setBrokerage(rs.getString("brokerage"));
				order.setTel(rs.getString("tel"));
				orders.add(order);
			}
			ps.close();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (con != null) {
					con.close();
					con = null;
				}
			} catch (Exception ex) {
			}
		}
		return orders;
	}
	//�鿴�ӵ����ж���
	public ArrayList orderquery(String tel) {
		Connection con = null;
		ArrayList orders = new ArrayList();
		try {
			
			Class.forName(driverClass);
			con = DriverManager.getConnection(database, username, password);
			
			String spl="SELECT * from wechar.`order` where orderID in(select orderID from wechar.orderreceive where tel=?)";
			PreparedStatement ps=con.prepareStatement(spl);
			ps.setString(1, tel);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				Order order = new Order();
				order.setOrderID(rs.getInt("orderID"));
				order.setReceive(rs.getString("receive"));
				order.setDestination(rs.getString("destination"));
				order.setBrokerage(rs.getString("brokerage"));
				order.setTel(rs.getString("tel"));
				orders.add(order);
			}
			ps.close();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (con != null) {
					con.close();
					con = null;
				}
			} catch (Exception ex) {
			}
		}
		return orders;
	}
	//����
	public int insert(String receive,String destination,String brokerage,String tel) throws ClassNotFoundException, SQLException{
		Connection con = null;
		int i=0;
		
		Class.forName(driverClass);
		con = DriverManager.getConnection(database, username, password);
			
		String sql = "insert into wechar.`order` (receive,destination,brokerage,tel,type) VALUES(?,?,?,?,1)";
		PreparedStatement pstat = con.prepareStatement(sql);
		pstat.setString(1, receive);
		pstat.setString(2, destination);
		pstat.setString(3, brokerage);
		pstat.setString(4, tel);
		i = pstat.executeUpdate();
		
		con.close();
		pstat.close();
		
		return i;
	}
	//�ӵ�
	public int Rorder(int orderID,String tel) throws ClassNotFoundException, SQLException{
		Connection con = null;
		int i=0;
		
		Class.forName(driverClass);
		con = DriverManager.getConnection(database, username, password);
			
		String sql = "insert into wechar.orderreceive (orderID,tel) VALUES(?,?)";
		PreparedStatement pstat = con.prepareStatement(sql);
		pstat.setInt(1, orderID);
		pstat.setString(2, tel);
		i = pstat.executeUpdate();
			
		con.close();
		pstat.close();
		
		return i;
	}
	//�ӵ���ı䶩��״̬
	public int update(int orderID)throws ClassNotFoundException, SQLException {
		Connection con = null;
		int i=0;
				
		Class.forName(driverClass);
		con = DriverManager.getConnection(database, username, password);
			
		String sql="update wechar.`order` set type=2 where orderID=?";
		PreparedStatement ps=con.prepareStatement(sql);
		ps.setInt(1, orderID);
		i=ps.executeUpdate();
			
		ps.close();
		con.close();
		
		return i;
	}
	//ɾ������
	public int delete1(int orderID) throws ClassNotFoundException, SQLException {	
		Connection con = null;
		int i=0;
		
		Class.forName(driverClass);
		con = DriverManager.getConnection(database, username, password);
		
		String sql="DELETE FROM wechar.`order` WHERE orderID=?";
		PreparedStatement pstat= con.prepareStatement(sql);
		pstat.setInt(1, orderID);				
		i=pstat.executeUpdate();
		
		pstat.close();
		con.close();
				
		return i;
	}
	

}
