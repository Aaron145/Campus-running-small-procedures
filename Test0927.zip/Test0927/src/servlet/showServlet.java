package servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import connect.Dconnect;

/**
 * Servlet implementation class showServlet
 */
@WebServlet("/showServlet")
public class showServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public showServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		ServletContext sc=this.getServletContext();
		String driverclass=sc.getInitParameter("driverclass");
		String database=sc.getInitParameter("database");
		String username=sc.getInitParameter("username");
		String password=sc.getInitParameter("password");
		
		String code=request.getParameter("code");
		int  n  = Integer.valueOf(code);
		
		Dconnect dconnect=new Dconnect(driverclass,database,username,password);
		
		if(n==3) {//code 3,�鿴���ж���	
			ArrayList arraylist=dconnect.query();
			response.getWriter().print(arraylist);
		}else if(n==4) {//code 4���鿴�Լ����ĵ�
			System.out.println("chaxun");
			String tel=request.getParameter("tel");
			ArrayList arraylist=dconnect.selfquery(tel);
			response.getWriter().print(arraylist);
		}else if(n==5){//code 5���鿴�Լ��ӵĵ�
			String tel=request.getParameter("tel");
			ArrayList arraylist=dconnect.orderquery(tel);
			response.getWriter().print(arraylist);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
