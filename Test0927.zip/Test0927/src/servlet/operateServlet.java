package servlet;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import connect.Dconnect;

/**
 * Servlet implementation class operateServlet
 */
@WebServlet("/operateServlet")
public class operateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public operateServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    int i;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		ServletContext sc=this.getServletContext();
		String driverclass=sc.getInitParameter("driverclass");
		String database=sc.getInitParameter("database");
		String username=sc.getInitParameter("username");
		String password=sc.getInitParameter("password");
		
		String tel=request.getParameter("tel");
		String receive=request.getParameter("receive");
		String destination=request.getParameter("destination");
		String brokerage=request.getParameter("brokerage");
		
		Dconnect dconnect=new Dconnect(driverclass,database,username,password);
			
		try {
			i = dconnect.insert(receive, destination, brokerage, tel);
			System.out.println("�ɹ�����"+i+"��");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		response.getWriter().write(i);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
