package servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import connect.Dconnect;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }   

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    int n=1;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		
		ServletContext sc=this.getServletContext();
		String driverclass=sc.getInitParameter("driverclass");
		String database=sc.getInitParameter("database");
		String username=sc.getInitParameter("username");
		String password=sc.getInitParameter("password");
		
		Dconnect dconnect=new Dconnect(driverclass,database,username,password);	
		
		String code=request.getParameter("code");
		int n  = Integer.valueOf(code);

		String name=request.getParameter("username");
		String tel=request.getParameter("tel");
		System.out.println("�û�����"+name+"���룺"+tel);
		
		if(n==1) {//code 1,��¼
			try {
		
				boolean i=dconnect.check(name, tel);
				
				if(i==true) {
					response.getWriter().write(tel);
					System.out.println("��½�ɹ�");
				}
				/*else {
					System.out.println("��¼ʧ��");
				}*/
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else if(n==2){//code 2��ע��
			try {
				boolean y = dconnect.registercheck(tel);
				
				if(y==true){
					int i=dconnect.register(name,tel);
					System.out.println("�ɹ�����"+i+"��");
					response.getWriter().write("success");
				}
				else{
					System.out.println("ע��ʧ��");
				}
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
