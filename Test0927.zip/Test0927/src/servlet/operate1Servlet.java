package servlet;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import connect.Dconnect;

/**
 * Servlet implementation class operate1Servlet
 */
@WebServlet("/operate1Servlet")
public class operate1Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public operate1Servlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    int i;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		
		ServletContext sc=this.getServletContext();
		String driverclass=sc.getInitParameter("driverclass");
		String database=sc.getInitParameter("database");
		String username=sc.getInitParameter("username");
		String password=sc.getInitParameter("password");
		
		Dconnect dconnect=new Dconnect(driverclass,database,username,password);
		
		String code=request.getParameter("code");
		int n  = Integer.valueOf(code);
		String o=request.getParameter("orderID");
		int orderID=Integer.parseInt(o);
		
		
		if(n==6) {//code 6���ӵ�
			try {System.out.println("66666");
				String tel=request.getParameter("tel");
				dconnect.update(orderID);
				i=dconnect.Rorder(orderID, tel);
				
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			response.getWriter().write(i);
		}else if(n==7) {//code 7��ɾ������
			try {System.out.println("77777");
				i=dconnect.delete1(orderID);
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			response.getWriter().write(i);
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
